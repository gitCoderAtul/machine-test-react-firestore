import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    value : []
}

const categorySlice = createSlice({
name : 'category',
initialState,
reducers:{
    addCategory:(state,action)=>{
        console.log('add category');
         console.log('state',state);
         console.log('action',action.payload);
        //  console.log(state.value);
         state.value.push(action.payload)
    },
    removeCategory:()=>{
        console.log('remove category');
    },
    deleteCategory:()=>{
        console.log('delete category');
    },

}
})

export const {addCategory,removeCategory,deleteCategory} = categorySlice.actions

export default categorySlice.reducer