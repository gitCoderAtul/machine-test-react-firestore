import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    value : []
}

const productSlice = createSlice({
name : 'products',
initialState,
reducers:{
    addProduct:()=>{
        console.log('add product');
    },
    removeProduct:()=>{
        console.log('remove product');
    },
    deleteProduct:()=>{
        console.log('delete product');
    },

}
})

export const {addProduct,removeProduct,deleteProduct} = productSlice.actions

export default productSlice.reducer