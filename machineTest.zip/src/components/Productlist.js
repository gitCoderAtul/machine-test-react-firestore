import React from "react"; 

export default function Productlist() {
   
  return (
    <div className="container mt-4">
      <div className="row">
        <h4 className="mb-5"> Products List </h4>

        <div className="col-md-8">
          <table class="table table-striped table-hover">
            <thead>
              <tr>
                <th scope="col">Sr No.</th>
                <th scope="col"> Category Id </th>
                <th scope="col">Category Master</th>
                <th scope="col"> Product Id </th>
                <th scope="col">Product Master</th>
                <th scope="col"> Action </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Cat id</td>
                <td>Cat Master</td>
                <td>Pro id</td>
                <td>Pro master</td>
                <td>
                  <button className="btn btn-sm btn-primary mx-2">
                    {" "}
                    Edit{" "}
                  </button>
                  <button className="btn btn-sm btn-danger"> Delete </button>
                </td>
              </tr>
            </tbody>
          </table>

          <nav aria-label="...">
            <ul class="pagination">
              <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1">
                  Previous
                </a>
              </li>
              <li class="page-item">
                <a class="page-link" href="#">
                  1
                </a>
              </li>
              <li class="page-item active">
                <a class="page-link" href="#">
                  2  
                </a>
              </li>
              <li class="page-item">
                <a class="page-link" href="#">
                  3
                </a>
              </li>
              <li class="page-item">
                <a class="page-link" href="#">
                  Next
                </a>
              </li>
            </ul>
          </nav>
          
        </div>
      </div>
    </div>
  );
}
